package ca.qc.cstj.consortium.domain.models

data class Trader(val name: String, var vethyx: Float, var lukryx: Float, var smiathil: Float, var bilerium: Float, var gloylium: Float)