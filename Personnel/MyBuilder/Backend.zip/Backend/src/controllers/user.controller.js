const User = require("../models/user.model");
const bcrypt = require('bcrypt');
const saltRounds = Math.floor(Math.random() * 12) + 10;

exports.getAll = function (req, res) {
  User.getAll((err, users) => {
    if (err) throw err;
    res.json(users);
  });
};

exports.getOne = function (req, res) {
  const user = {
    email: req.body.email,
    username: req.body.username,
    password: ''
  };

  bcrypt.hash(req.body.password, saltRounds, (err, hash) => {
    if (err) {
      console.error('Error hashing password:', err);
      return;
    }

    user.password = hash;
    User.getOne(user, (err, user) => {
      if (err) throw err;

      if (req.body.email) {
        res.json({ message: `Connected as '${req.body.email}'.` });
      } else {
        res.json({ message: `Connected as '${req.body.username}'.` });
      }
    });
  });
};

exports.create = function (req, res) {
  const newUser = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    email: req.body.email,
    username: req.body.username,
    password: '',
    role: req.body.role,
    age: req.body.age
  };

  bcrypt.hash(req.body.password, saltRounds, (err, hash) => {
    if (err) {
      console.error('Error hashing password:', err);
      return;
    }

    newUser.password = hash;
    User.create(newUser, (err, result) => {
      if (err) throw err;
      res.json({ message: `The user ${req.body.firstName} was created successfully.` });
    });
  });
};

exports.update = function (req, res) {
  const updatedUser = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    email: req.body.email,
    username: req.body.username,
    password: '',
    role: req.body.role,
    age: req.body.age
  };

  bcrypt.hash(req.body.password, saltRounds, (err, hash) => {
    if (err) {
      console.error('Error hashing password:', err);
      return;
    }

    updatedUser.password = hash;
    User.update(req.params.id, updatedUser, (err, result) => {
      if (err) throw err;
      res.json({ message: `The user ${req.params.id} was updated successfully.` });
    });
  });
};

exports.delete = function (req, res) {
  User.delete(req.params.id, (err, result) => {
    if (err) throw err;
    res.json({ message: `The user ${req.params.id} was deleted successfully.` });
  });
};
