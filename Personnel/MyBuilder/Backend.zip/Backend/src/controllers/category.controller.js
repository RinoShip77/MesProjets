const Category = require("../models/category.model");

exports.getAll = function (req, res) {
  Category.getAll((err, categories) => {
    if (err) throw err;
    res.json(categories);
  });
};

exports.create = function (req, res) {
  const newCategory = req.body.title;

  Category.create(newCategory, (err, result) => {
    if (err) throw err;
    res.json({
      message: `The category ${req.body.title} was created successfully.`,
    });
  });
};

exports.update = function (req, res) {
  const updatedCategory = req.body.title;

  Category.update(req.params.title, updatedCategory, (err, result) => {
    if (err) throw err;
    res.json({
      message: `The category ${req.params.title} was rename to ${req.body.title}.`,
    });
  }
  );
};

exports.delete = function (req, res) {
  Category.delete(req.params.title, (err, result) => {
    if (err) throw err;
    res.json({
      message: `The category ${req.params.title} and all of his products where deleted successfully.`,
    });
  });
};
