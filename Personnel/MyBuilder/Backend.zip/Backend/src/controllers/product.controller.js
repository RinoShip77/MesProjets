const Product = require("../models/product.model");

exports.getAll = function (req, res) {
  Product.getAll(req.params.table, (err, products) => {
    if (err) throw err;
    res.json(products);
  });
};

exports.getOne = function (req, res) {
  Product.getOne(req.params.table, req.params.id, (err, product) => {
    if (err) throw err;
    res.json(...product);
  });
};

exports.create = function (req, res) {
  const newProduct = {
    name: req.body.name,
    imageURL: req.body.imageURL,
    productURL: req.body.productURL,
    price: req.body.price,
    manufacturer: req.body.manufacturer,
    uuid: req.body.uuid,
    type: req.body.type,
    color: req.body.color,
    powerSupply: req.body.powerSupply,
    sidePanel: req.body.sidePanel,
    powerSupplyShroud: req.body.powerSupplyShroud,
    frontPanelUSB: req.body.frontPanelUSB,
    motherboardFormFactor: req.body.motherboardFormFactor,
    maximumVideoCardLength: req.body.maximumVideoCard,
    driveBays: req.body.driveBays,
    expansionSlots: req.body.expansionSlots,
    dimensions: req.body.dimensions,
    volume: req.body.volume
  };

  Product.create(req.params.table, newProduct, (err, result) => {
    if (err) throw err;
    res.json({
      message: `The ${req.params.table} was created successfully.`,
    });
  });
};

exports.update = function (req, res) {
  const updatedProduct = {
    name: req.body.name,
    imageURL: req.body.imageURL,
    productURL: req.body.productURL,
    price: req.body.price,
    manufacturer: req.body.manufacturer,
    uuid: req.body.uuid,
    type: req.body.type,
    color: req.body.color,
    powerSupply: req.body.powerSupply,
    sidePanel: req.body.sidePanel,
    powerSupplyShroud: req.body.powerSupplyShroud,
    frontPanelUSB: req.body.frontPanelUSB,
    motherboardFormFactor: req.body.motherboardFormFactor,
    maximumVideoCardLength: req.body.maximumVideoCard,
    driveBays: req.body.driveBays,
    expansionSlots: req.body.expansionSlots,
    dimensions: req.body.dimensions,
    volume: req.body.volume
  };

  Product.update(req.params.table, req.params.id, updatedProduct, (err, result) => {
    if (err) throw err;
    res.json({
      message: `The ${req.params.table} ${req.params.id} was updated successfully.`,
    });
  });
};

exports.delete = function (req, res) {
  Product.delete(req.params.table, req.params.id, (err, result) => {
    if (err) throw err;
    res.json({
      message: `The ${req.params.table} ${req.params.id} was deleted successfully.`,
    });
  });
};
